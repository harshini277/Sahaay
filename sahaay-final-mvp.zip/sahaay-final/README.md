# Sahaay

Sahaay is a citizen-first grievance guidance experience inspired by CPGRAMS.

## Local
Use the existing project dependencies, then run:
- `npm run dev`
- `npm run build`

## Vercel
This is a Vite SPA and includes `vercel.json` for client-side route rewrites.
Import the project into Vercel and deploy with the default settings.

## Demo account
Provide the competition credentials separately. The app intentionally does not display them in the UI.

## Important
Government submission, identity verification, routing, documents and notifications are represented with synthetic data. No production government system is connected.

## Authority directory
The responsible-authority layer uses a structured demo directory covering representative Indian states/cities plus a safe nationwide fallback. Officer names, phone numbers and email addresses shown in the demo are synthetic and are explicitly labelled as such in the UI. A production deployment should replace these records with verified, versioned government directories/APIs and retain a source + last-verified timestamp.
